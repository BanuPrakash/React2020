import React from 'react'
import { observer } from 'mobx-react'

function List(props) {
  return (
    <div className="card">
      <div className="card-body">
          <div>
            <p>{props.list.value}</p>
            <div>
            <button onClick={props.deleteList.bind(this, props.list)} >Delete</button>
            </div>
          </div>
      </div>
    </div>
  )
}

export default observer(List)
