import { observable, action, computed,makeObservable } from "mobx";


import { v4 } from "uuid";

export class List {
  value
  done

  constructor (data) {
    this.id = v4()
    this.value = data;
    this.done = false;
    makeObservable(this, {
        value: observable,
        done: observable
    })
   
  }
}



 export  class ListStore {
  lists = []
  filter = ""
   constructor() {
    makeObservable(this, {
        lists: observable,
        addList: action,
        deleteList: action,
        filteredLists: computed
    })
   }
  addList = (value) => {
    this.lists.push(new List(value))
  }
 
  deleteList = (list) => {
    this.lists = this.lists.filter(t => t !== list)
  }

  get filteredLists () {
    return this.lists.filter(list=> list.done === false)
    //return this.lists;
  }
}
